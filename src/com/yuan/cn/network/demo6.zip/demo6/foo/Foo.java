package com.yuan.cn.network.demo6.foo;

public class Foo {
}
